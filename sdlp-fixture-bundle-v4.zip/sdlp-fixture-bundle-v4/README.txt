SDLP fixture bundle v4 — EMILIA-generated

Inputs
------
Native source: draft-norton-sdlp-obj-format-07, Section 3.9
Lineage source: draft-norton-sdlp-lineage-03

The positive native case uses the exact five published lines, exactly four LF
separators, no trailing LF, and reproduces the published SHA-256:
4e121057d46afec547e04ec63194ffd8a1e27178e06ba563b760fb35a436f32b

This bundle supplies a fresh Ed25519 test key and detached test signature over
those exact bytes, 11 native negative controls, a pinned mapping profile, and
seven separate EMILIA consequence-boundary cases.

Important boundary
------------------
Object Format -07 does not bind DigitalID to a signing key and does not mandate
this detached signature-envelope shape. The native signature result therefore
proves only that the fixture key signed the exact bytes. It does not establish
principal authority, action authorization, Gate admission, provider invocation,
or outcome. The first EMILIA case proves this stop explicitly.

The positive cross-stack case uses a relying-party mapping profile that binds
the exact verified object digest to a local provenance-record registration
action. That mapping is explicit and SHA-256 pinned; it is not inferred from the
SDLP Body or DigitalID. Gate stops at RESERVED and does not invoke a provider.

Run
---
1. Save SDLP-fixture-bundle-v4-runner.txt beside SDLP-fixture-bundle-v4.json.
2. Rename the runner to SDLP-fixture-bundle-v4-runner.mjs.
3. Run: node SDLP-fixture-bundle-v4-runner.mjs

Expected terminal line:
All 12 native and 7 EMILIA cases passed

No private key or seed is included.
